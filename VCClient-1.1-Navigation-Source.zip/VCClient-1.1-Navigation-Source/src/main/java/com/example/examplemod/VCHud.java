package com.example.examplemod;
import net.minecraft.client.Minecraft; import net.minecraftforge.client.event.RenderGameOverlayEvent; import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
public class VCHud {
 public boolean enabled=true; private final Minecraft mc=Minecraft.getMinecraft();
 @SubscribeEvent public void render(RenderGameOverlayEvent.Text e){if(!enabled||mc.thePlayer==null)return;int y=6;mc.fontRendererObj.drawStringWithShadow("VC Client",6,y,0x55AAFF);y+=11;mc.fontRendererObj.drawStringWithShadow("FPS: "+Minecraft.getDebugFPS(),6,y,0xFFFFFF);y+=11;mc.fontRendererObj.drawStringWithShadow("XYZ: "+(int)mc.thePlayer.posX+" "+(int)mc.thePlayer.posY+" "+(int)mc.thePlayer.posZ,6,y,0xFFFFFF);}
}