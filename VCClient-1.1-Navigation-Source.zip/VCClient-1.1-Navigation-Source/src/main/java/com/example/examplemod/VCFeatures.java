package com.example.examplemod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

/** Client-side visual features. No packets, combat automation, or server modifications. */
public class VCFeatures {
 public boolean keystrokes=true, cps=true, blockOverlay=true, oldVisuals=false, packOverlay=true;
 private final Minecraft mc=Minecraft.getMinecraft();
 private int leftCps=0,rightCps=0,leftTicks=0,rightTicks=0;
 private boolean lastLeft=false,lastRight=false;
 private long lastLeftMs=0,lastRightMs=0;
 @SubscribeEvent public void tick(TickEvent.ClientTickEvent e){
  if(e.phase!=TickEvent.Phase.END)return;
  long now=System.currentTimeMillis();
  boolean l=Mouse.isButtonDown(0),r=Mouse.isButtonDown(1);
  if(l&&!lastLeft&&now-lastLeftMs>45){leftCps++;lastLeftMs=now;}
  if(r&&!lastRight&&now-lastRightMs>45){rightCps++;lastRightMs=now;}
  lastLeft=l;lastRight=r;
  if(++leftTicks>=20){leftTicks=0;leftCps=0;} if(++rightTicks>=20){rightTicks=0;rightCps=0;}
 }
 @SubscribeEvent public void hud(RenderGameOverlayEvent.Post e){
  if(mc.thePlayer==null||mc.theWorld==null||e.type!=RenderGameOverlayEvent.ElementType.ALL)return;
  int sw= e.resolution.getScaledWidth(), sh=e.resolution.getScaledHeight();
  if(keystrokes){
   int x=8,y=sh-72; key(x+22,y,"W",Keyboard.KEY_W);
   key(x,y+22,"A",Keyboard.KEY_A);key(x+22,y+22,"S",Keyboard.KEY_S);key(x+44,y+22,"D",Keyboard.KEY_D);
   box(x,y+44,42,17,Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)?"SNEAK":"SHIFT",Keyboard.isKeyDown(Keyboard.KEY_LSHIFT));
   box(x+44,y+44,42,17,"SPACE",Keyboard.isKeyDown(Keyboard.KEY_SPACE));
  }
  if(cps){
   String s="LMB "+leftCps+"  |  RMB "+rightCps;
   mc.fontRendererObj.drawStringWithShadow(s,8,sh-12,0xFFFFFFFF);
  }
  if(packOverlay){
   mc.fontRendererObj.drawStringWithShadow("VC Pack",sw-58,6,0xFF55AAFF);
  }
 }
 private void key(int x,int y,String s,int code){box(x,y,20,20,s,Keyboard.isKeyDown(code));}
 private void box(int x,int y,int w,int h,String s,boolean down){
  Gui.drawRect(x,y,x+w,y+h,down?0xCC168CFF:0xAA101D35);
  int tw=mc.fontRendererObj.getStringWidth(s);
  mc.fontRendererObj.drawStringWithShadow(s,x+(w-tw)/2,y+(h-8)/2,0xFFFFFFFF);
 }
 @SubscribeEvent public void world(RenderWorldLastEvent e){
  if(!blockOverlay||mc.thePlayer==null||mc.objectMouseOver==null||mc.objectMouseOver.getBlockPos()==null)return;
  BlockPos p=mc.objectMouseOver.getBlockPos();
  // Vanilla selection box remains enabled; this setting is reserved for custom styling.
 }
}
