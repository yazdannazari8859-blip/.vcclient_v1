package com.example.examplemod;
import net.minecraft.client.Minecraft; import net.minecraftforge.fml.common.eventhandler.SubscribeEvent; import net.minecraftforge.fml.common.gameevent.TickEvent;
public class VCToggleSprint {
 private final Minecraft mc=Minecraft.getMinecraft(); private boolean enabled;
 public boolean isEnabled(){return enabled;} public void toggle(){enabled=!enabled;}
 @SubscribeEvent public void tick(TickEvent.ClientTickEvent e){if(e.phase==TickEvent.Phase.END&&enabled&&mc.thePlayer!=null&&mc.currentScreen==null&&mc.thePlayer.moveForward>0&&!mc.thePlayer.isSneaking())mc.thePlayer.setSprinting(true);}
}