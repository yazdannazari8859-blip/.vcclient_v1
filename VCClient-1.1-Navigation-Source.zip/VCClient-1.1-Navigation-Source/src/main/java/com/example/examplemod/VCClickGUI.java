package com.example.examplemod;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
public class VCClickGUI extends GuiScreen {
 private final String[] names={"Cosmetic","Toggle Sprint","HUD","Keystroke","CPS","Nick Name","Block Overlay","1.7 Visual","Pack Overlay"};private int x,y;
 @Override public void initGui(){buttonList.clear();x=(width-320)/2;y=(height-240)/2;
  for(int i=0;i<names.length;i++){boolean on=state(i);buttonList.add(new GuiButton(i,x+12+(i%2)*150,y+38+(i/2)*32,140,22,names[i]+(i==0||i==5?"":on?" [ON]":" [OFF]")));}
  buttonList.add(new GuiButton(99,x+12,y+205,296,22,"Close"));}
 private boolean state(int i){switch(i){case 1:return ExampleMod.sprint.isEnabled();case 2:return ExampleMod.hud.enabled;case 3:return ExampleMod.features.keystrokes;case 4:return ExampleMod.features.cps;case 6:return ExampleMod.features.blockOverlay;case 7:return ExampleMod.features.oldVisuals;case 8:return ExampleMod.features.packOverlay;default:return false;}}
 @Override public void drawScreen(int mx,int my,float pt){drawDefaultBackground();drawRect(x,y,x+320,y+240,0xF20A1224);drawRect(x,y,x+320,y+3,0xFF168CFF);drawString(fontRendererObj,"VC CLIENT",x+12,y+13,0xFF168CFF);drawString(fontRendererObj,"Right Shift • Forge 1.8.9",x+12,y+25,0xFF9AB9DF);super.drawScreen(mx,my,pt);}
 @Override protected void actionPerformed(GuiButton b)throws IOException{switch(b.id){
  case 0:mc.displayGuiScreen(new VCCosmeticsGUI());return;
  case 1:ExampleMod.sprint.toggle();break;case 2:ExampleMod.hud.enabled=!ExampleMod.hud.enabled;break;
  case 3:ExampleMod.features.keystrokes=!ExampleMod.features.keystrokes;break;case 4:ExampleMod.features.cps=!ExampleMod.features.cps;break;
  case 5:mc.displayGuiScreen(new VCNicknameGUI());return;case 6:ExampleMod.features.blockOverlay=!ExampleMod.features.blockOverlay;break;
  case 7:ExampleMod.features.oldVisuals=!ExampleMod.features.oldVisuals;break;case 8:ExampleMod.features.packOverlay=!ExampleMod.features.packOverlay;break;
  case 99:mc.displayGuiScreen(null);return;default:return;}initGui();}
 @Override public boolean doesGuiPauseGame(){return false;}
}
