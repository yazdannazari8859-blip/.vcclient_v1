package com.example.examplemod;
import net.minecraft.client.Minecraft; import net.minecraft.client.settings.KeyBinding; import net.minecraftforge.fml.client.registry.ClientRegistry; import net.minecraftforge.fml.common.eventhandler.SubscribeEvent; import net.minecraftforge.fml.common.gameevent.InputEvent; import org.lwjgl.input.Keyboard;
public class VCMenuKey {
 private final Minecraft mc=Minecraft.getMinecraft(); private final KeyBinding key=new KeyBinding("key.vcclient.openMenu",Keyboard.KEY_RSHIFT,"key.categories.vcclient");
 public VCMenuKey(){ClientRegistry.registerKeyBinding(key);}
 @SubscribeEvent public void input(InputEvent.KeyInputEvent e){if(key.isPressed()){if(mc.currentScreen instanceof VCClickGUI)mc.displayGuiScreen(null);else if(mc.currentScreen==null)mc.displayGuiScreen(new VCClickGUI());}}
}