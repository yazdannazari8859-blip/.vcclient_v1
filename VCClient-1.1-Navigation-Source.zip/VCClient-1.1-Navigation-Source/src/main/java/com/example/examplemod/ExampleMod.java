package com.example.examplemod;
import java.io.File;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.MinecraftForge;
@Mod(modid=ExampleMod.MODID,name="VC Client",version=ExampleMod.VERSION,clientSideOnly=true)
public class ExampleMod {
 public static final String MODID="vcclient", VERSION="1.1";
 public static VCToggleSprint sprint; public static VCCosmetics cosmetics; public static VCHud hud;
 public static VCFeatures features;
 @Mod.EventHandler public void preInit(FMLPreInitializationEvent e){VCNameSettings.load(new File(e.getModConfigurationDirectory(),"vcclient.cfg"));}
 @Mod.EventHandler public void init(FMLInitializationEvent e){
  sprint=new VCToggleSprint(); cosmetics=new VCCosmetics(); hud=new VCHud(); features=new VCFeatures();
  MinecraftForge.EVENT_BUS.register(sprint); MinecraftForge.EVENT_BUS.register(cosmetics);
  MinecraftForge.EVENT_BUS.register(hud); MinecraftForge.EVENT_BUS.register(features);
  MinecraftForge.EVENT_BUS.register(new VCMenuKey());
 }
}
