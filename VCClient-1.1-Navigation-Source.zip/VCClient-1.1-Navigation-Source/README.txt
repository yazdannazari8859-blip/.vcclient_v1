VCClient 1.1 - Navigation source update
Minecraft Java 1.8.9 / Forge 11.15.1.2318

This package is SOURCE CODE, not a compiled JAR.

Navigation focus:
- Right Shift opens VCClickGUI.
- Cosmetic opens VCCosmeticsGUI.
- Nick Name opens VCNicknameGUI.
- Cosmetics and nickname pages include Back controls.
- Cosmetics has Apply and toggles for Wings, Dog Pet, Shoulder Wither, Shoulder Parrot.

Important limitations:
- This source package has not been compiled or tested in-game in this environment.
- It is not verified to be the exact source used to build the uploaded VCClient-1.0.jar.
- Dog/wither/parrot companion rendering and some other features are placeholders/incomplete.
- Keep VCClient-1.0.jar as a backup and do not replace it until a rebuilt JAR is tested.

Build requires a compatible Java 8 + Gradle/ForgeGradle 2.1 environment and network access to dependencies.
